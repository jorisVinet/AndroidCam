//
// Created by yoj49 on 25/01/2024.
//

#ifndef IOTPROJECTNATIVE_SOCKET_CLIENT_H
#define IOTPROJECTNATIVE_SOCKET_CLIENT_H
#include <opencv2/core.hpp>

class SocketClient {
public:
    SocketClient(const char* hostname, int port);
    void ConnectToServer();
    void SendImageDims(const int image_rows, const int image_cols);
    void SendImage(cv::Mat& image);
    void SendImageH264(const uint8_t * image, int size);
private:
    const char* hostname_;
    int port_;
    int pic_num_;
    int socket_fdesc_;
};
#endif //IOTPROJECTNATIVE_SOCKET_CLIENT_H
