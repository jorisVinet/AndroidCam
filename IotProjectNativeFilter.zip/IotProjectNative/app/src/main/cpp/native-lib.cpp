#include <jni.h>
#include <string>
#include "CV_Manager.h"
#include <Android/native_window_jni.h>
#include <Android/asset_manager_jni.h>

static CV_Manager app;
extern "C"
JNIEXPORT void JNICALL
Java_com_example_iotprojectnative_MainActivity_setSurface(JNIEnv *env, jobject thiz,
                                                          jobject surface) {
    // TODO: implement setSurface()

    app.SetNativeWindow(ANativeWindow_fromSurface(env,surface));
    app.SetUpCamera();
    app.SetUpServer();
    app.SetUpEncoder();

    std::thread LoopThread(&CV_Manager::CameraLoop, &app);
    LoopThread.detach();

}
extern "C"
JNIEXPORT void JNICALL
Java_com_example_iotprojectnative_MainActivity_releaseCVMain(JNIEnv *env, jobject thiz) {
    // TODO: implement releaseCVMain()
}
extern "C"
JNIEXPORT void JNICALL
Java_com_example_iotprojectnative_MainActivity_pauseCamera(JNIEnv *env, jobject thiz) {
    // TODO: implement pauseCamera()

    app.PauseCamera();

}


extern "C"
JNIEXPORT void JNICALL
Java_com_example_iotprojectnative_MainActivity_changeMode(JNIEnv *env, jobject thiz, jstring filter) {
    // TODO: implement changeMode()

    const jclass stringClass = env->GetObjectClass(filter);
    const jmethodID getBytes = env->GetMethodID(stringClass, "getBytes", "(Ljava/lang/String;)[B");
    const jbyteArray stringJbytes = (jbyteArray) env->CallObjectMethod(filter, getBytes, env->NewStringUTF("UTF-8"));

    size_t length = (size_t) env->GetArrayLength(stringJbytes);
    jbyte* pBytes = env->GetByteArrayElements(stringJbytes, NULL);

    std::string ret = std::string((char *)pBytes, length);
    env->ReleaseByteArrayElements(stringJbytes, pBytes, JNI_ABORT);

    env->DeleteLocalRef(stringJbytes);
    env->DeleteLocalRef(stringClass);

    app.ChangeMode(ret);

}