package com.example.iotprojectnative;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.WindowManager;
import android.widget.Toast;
import androidx.core.app.ActivityCompat;
import android.util.DisplayMetrics;
import androidx.core.content.ContextCompat;
import android.widget.TextView;

import com.example.iotprojectnative.databinding.ActivityMainBinding;

public class MainActivity extends Activity {

    // Used to load the 'iotprojectnative' library on application startup.
    static {
        System.loadLibrary("iotprojectnative");
    }
    public static final String TAG = "NativeBarcodeTracker";
    private int CAMERA_PERMISSION_CODE = 1;

    SurfaceView mSurfaceView;
    SurfaceHolder mSurfaceHolder;

    Button mFlipCamera;

    Button mInvertColor;

    Spinner mfilterSpinner;

    //private ActivityMainBinding binding;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        mSurfaceView = (SurfaceView)findViewById(R.id.texturePreview);
        mFlipCamera = (Button) findViewById(R.id.FlipCamera);
        mFlipCamera.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                pauseCamera();
            }
        });

        /*mInvertColor = (Button) findViewById(R.id.InvertColor);
        mInvertColor.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { changeMode();
            }
        });*/

        mfilterSpinner = findViewById(R.id.filterSpinner);

        // Liste des filtres
        String[] filters = {"Basic", "Invert_Color", "Blur", "Edge_Detector", "Zoom"};

        // Création de l'ArrayAdapter
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, filters);

        // Spécifier le layout à utiliser lorsque la liste des choix apparaît
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // Appliquer l'adapter au Spinner
        mfilterSpinner.setAdapter(adapter);

        // Écouteur d'événements pour le Spinner
        mfilterSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Récupérer le filtre sélectionné
                String selectedFilter = parent.getItemAtPosition(position).toString();

                // Exécuter la fonction avec le filtre sélectionné comme entrée
                changeMode(selectedFilter);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Gérer l'événement lorsqu'aucun élément n'est sélectionné
                changeMode("Basic");
            }
        });


        mSurfaceHolder = mSurfaceView.getHolder();

        mSurfaceHolder.addCallback(new SurfaceHolder.Callback() {
                                       @Override
                                       public void surfaceCreated(SurfaceHolder surfaceHolder) {
                                           if (ContextCompat.checkSelfPermission(
                                                   MainActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                                               // Sends surface buffer to NDK
                                               setSurface(surfaceHolder.getSurface());
                                           } else {
                                               requestCameraPermission();
                                           }
                                       }

           @Override
           public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i1, int i2) {

           }

           @Override
           public void surfaceDestroyed(SurfaceHolder surfaceHolder) {

           }
        });

        // Récupérer les dimensions de l'écran
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        int screenWidth = metrics.widthPixels;
        int screenHeight = metrics.heightPixels;
    }

    /**
     * A native method that is implemented by the 'iotprojectnative' native library,
     * which is packaged with this application.
     */

    private void requestCameraPermission() {
        ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.CAMERA}, CAMERA_PERMISSION_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == CAMERA_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Sends surface buffer to NDK
                setSurface(mSurfaceHolder.getSurface());
            } else {
                Toast.makeText(getApplicationContext(), "Please allow permission to use the camera",
                        Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        releaseCVMain();
    }


    // Sends surface buffer to NDK
    public native void setSurface(Surface surface);
    // Release native resources
    public native void releaseCVMain();
    //public native String stringFromJNI();

    public native void pauseCamera();

    public native void changeMode(String filter);
}